package application;
import java.util.ArrayList;

import javafx.*;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
import javafx.scene.control.CheckBox;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class Laureate1 {
	@FXML
	private TableView<Laureate> table;
	@FXML
	private TextField firstName;
	@FXML
	private TextField lastName;
	@FXML
	private TextField bornDate;
	@FXML
	private TextField diedDate;
	@FXML
	private TextField country;
	@FXML
	private ComboBox<String> box;
	@FXML
	private CheckBox male;
	@FXML
	private TableColumn<Laureate, String> firstNameCol;
	@FXML
	private TableColumn<Laureate, String> lastNameCol;
	@FXML
	private CheckBox female;
	
	
	private String firstNameText="";
	private String lastNameText="";
	private String birthYear="";
	private String deathYear="";
	private String category ="";
	private String gender = "";
	private String countryText = "";
	private ArrayList<Laureate> laurList = new ArrayList<>();
	private ObservableList<String> list = FXCollections.observableArrayList();
	
	
	
	public Laureate1(){
		
	}
	private Main app;
	
	@FXML
	private void initialize() throws Exception{
        
		String physics = "Physics";
		String medicine = "Medicine";
		String peace = "Peace";
		String chemistry = "Chemistry";
		String lit = "Literature";
		String econ = "Economics";
		list.add(physics);
		list.add(peace);
		list.add(chemistry);
		list.add(medicine);
		list.add(lit);
		list.add(econ);
		box.getItems().addAll(list);
		
	}
	public void printTextField() throws Exception{
		Laureates pool = new Laureates();
        Database data = pool.makeDatabase();
		if (!firstName.getText().equals("")){
		firstNameText = firstName.getText().toLowerCase();
		}
		if (!lastName.getText().equals("")){
		lastNameText = lastName.getText().toLowerCase();
		}
		if (!bornDate.getText().equals("")){
			birthYear = bornDate.getText().toLowerCase();
		}
		if (!diedDate.getText().equals("")){
			deathYear = bornDate.getText().toLowerCase();
		}
		if (box.getValue() != null){
			category = box.getValue().toLowerCase();
		}
		if (male.isSelected()){
			gender = "male";
		}
		if (female.isSelected()){
			gender = "female";
		}
		if (!country.getText().equals("")){
			countryText = country.getText().toLowerCase();
		}
		Query test = new Query(firstNameText, lastNameText, birthYear, deathYear, category, gender, countryText);
		laurList = data.runQuery(test);
		for (int i = 0; i < laurList.size(); i++) {
            System.out.println(laurList.get(i).getFirstName() + " " + laurList.get(i).getLastName() + " " + laurList.get(i).getMotivation() + " " + laurList.get(i).getCategory() + " " + laurList.get(i).getCountry());
        }
		
	}
	
	public void setMainApp(Main app){
		this.app = app;
	}
	
}
