package application;

import java.util.ArrayList;

import javafx.beans.property.SimpleStringProperty;
import javafx.beans.property.StringProperty;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.fxml.FXML;
public class LaureateModel {
	@FXML
	private StringProperty firstName;
	@FXML
	private StringProperty lastName;
	private ObservableList<LaureateModel> personData = FXCollections.observableArrayList();
	public LaureateModel(Laureate obj){
		
		this.firstName = new SimpleStringProperty(obj.getFirstName());
		
	}
	public StringProperty getFirstNameProperty(){
		return firstName;
	}
	public String getFirstName(){
		return firstName.get();
	}
	public String getLastName(){
		return lastName.get();
	}
	public StringProperty getLastNameProperty(){
		return lastName;
	}
	
}
